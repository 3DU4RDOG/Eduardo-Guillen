document.addEventListener("DOMContentLoaded", function () {
    // Alerta que demuestra el enlace correcto del JS según la página actual
    if (document.getElementById("pagina-inicio")) {
        alert("¡Bienvenido a Veterinaria Huellitas - Página de Inicio!");
    } else if (document.getElementById("pagina-servicios")) {
        alert("¡Bienvenido a Veterinaria Huellitas - Sección Servicios!");
    }
});